#include <stdio.h>

int main()
{
    printf("|H|\t |H| |E||E||E||E|  |L|           |L|                   |O||O||O||O|\n");
    printf("|H|\t |H| |E| \t   |L|           |L|                 |O|           |O|\n");
    printf("|H|\t |H| |E| \t   |L|           |L|                 |O|           |O|\n");
    printf("|H|\t |H| |E| \t   |L|           |L|                 |O|           |O|\n");
    printf("|H||H||H||H| |E||E||E|     |L|           |L|                 |O|           |O|\n");
    printf("|H|\t |H| |E| \t   |L|           |L|                 |O|           |O|\n");
    printf("|H|\t |H| |E| \t   |L|           |L|                 |O|           |O|\n");
    printf("|H|\t |H| |E| \t   |L|           |L|                 |O|           |O|\n");
    printf("|H|\t |H| |E||E||E||E|  |L||L||L||L|  |L||L||L||L|          |O||O||O||O|\n");
    return 0;
}