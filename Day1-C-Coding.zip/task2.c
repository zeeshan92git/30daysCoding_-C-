#include <stdio.h>
int main(){
    printf("This is Master in 'C Language'30 days course.\nthis course is organized by Tech Involvers");
    return 0;
}