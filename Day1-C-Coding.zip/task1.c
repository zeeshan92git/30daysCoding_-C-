#include <stdio.h>
int main(){
    printf("My name is Muhammad Talha");
    return 0;
}