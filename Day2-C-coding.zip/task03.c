#include <stdio.h>
int main()
{
    int n1;
    double n2;
    printf("Enter First Number:");
    scanf("%d", &n1);
    printf("Enter Second Number:");
    scanf("%lf", &n2);
    if(n1==n2)
        printf("1\n");
    else
        printf("0\n");
}