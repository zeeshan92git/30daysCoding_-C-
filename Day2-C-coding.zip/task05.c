#include <stdio.h>
int main()
{
    int age;
    printf("Enter Age:");
    scanf("%d", &age);
    (age >= 18) ? printf("Bravo! You are eligible for vote "):printf(" Sorry,you are not eligible for vote ");
}