#include<stdio.h>
int main(){
    int length,width;
    printf("Enter Length of Rectangle:");
    scanf("%d", &length);
    printf("Enter Width of Rectangle:");
    scanf("%d", &width);
    int Area = length * width;
    printf("Area of Rectangle is= %d", Area);
}