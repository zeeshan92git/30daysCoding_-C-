#include<stdio.h>
int main(){
   int n1,n2,n3,n4,n5;
   printf("Enter five Numbers:");
   scanf("%d %d %d %d %d", &n1, &n2, &n3, &n4, &n5);
   int sum = n1+n2+ n3+n4+n5;
   float Average=sum/5.0;
   printf("Sum: %d\n",sum);
   printf("Average: %.2f\n", Average);
}