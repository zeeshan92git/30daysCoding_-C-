#include <stdio.h>

int main()
{
    int n1;
    int n2;
    printf("Enter Two Number:");
    scanf("%d %d", &n1, &n2);
    printf("%d & %d = %d\n", n1, n2, n1 & n2);
    printf("%d | %d = %d\n", n1, n2, n1 | n2);
    printf("%d ^ %d = %d\n", n1, n2, n1 ^ n2);
    printf("%d >> %d = %d\n", n1, n2, n1 >> n2);
    printf("%d << %d = %d\n", n1, n2, n1 << n2);
    return 0;
}
