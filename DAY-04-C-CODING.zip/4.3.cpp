#include <stdio.h>
#include <stdlib.h>

void swap(int &x, int &y) {
   
    x = x ^ y;
    y = x ^ y;
    x = x ^ y;
}
int main()
{
	int num1,num2;
	printf("Enter Number1:");
	scanf("%d",&num1);
	printf("Enter Number2:");
	scanf("%d",&num2);
	swap(num1,num2);
	printf("Number 1: %d\n",num1);
	printf("Number 2: %d",num2);
	return 0;
}