#include <stdio.h>
#include <stdlib.h>

int main()
{
	int num,fac=1;
	printf("Number:");
	scanf("%d",&num);
	for(int i=num; i>=1; i--){
		fac = fac * i ;
	}
	printf("Factorial: %d",fac);
	return 0;
}