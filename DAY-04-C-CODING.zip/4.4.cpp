#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int number, guess, tries = 0;
    srand(time(0));
    number = rand() % 11 + 10; 

    printf("Guess the number(10-20): ");
    do {
        scanf("%d", &guess);
        tries++;

        if (guess < number) {
            printf("Too low! Try Again.\n");
        } else if (guess > number) {
            printf("Too high! Try Again.\n");
        } else {
            printf("Bravo! You guessed the number in %d tries.\n", tries);
        }
    } while (guess != number);

    return 0;
}
