#include <stdio.h>
#include <stdlib.h>


int main()
{
	int num1,sum=0;
	printf("Enter Number1:");
	scanf("%d",&num1);
	for(int i=0; i<=num ;i++){
		sum += i;
	}
	printf("Sum: %d",sum);
	return 0;
}