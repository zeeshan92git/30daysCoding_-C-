# include <stdio.h>
# include <stdlib.h>
#include <time.h>
int main()
{
	srand(time(0));
	int a, b ;
	a = rand() % 90 + 10;
	b = rand() % a ;
	printf("Two Random Numbers: %d %d\n",a,b);
	int c = a + b ;
	if(c%2==0){
		printf("Their sum is Even");
	}
	else{
		printf("Their sum is Odd");
	}
	return 0;
}