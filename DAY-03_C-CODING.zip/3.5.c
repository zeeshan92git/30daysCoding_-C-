#include <stdio.h>
#include <stdlib.h>


int main() {
    char consumer_type;
    int unit,fixTax,GST,unitPrice,TotalBill;
    printf("Select the Cosumer Type:\n");
    printf("C for commercial\n");
    printf("H for home\n");
    do{
    	printf("Enter consumer Type:");
    	scanf(" %c",&consumer_type);
    }while( consumer_type!='H' && consumer_type!='C');
    printf("Enter No. OF Units Consumed:");
    scanf("%d",&unit);
    
    if(consumer_type == 'H'){
    	if(unit <=100) unitPrice = unit * 11;
    	else if(unit >100 && unit <= 200){
    		unitPrice = 100 * 11 ;
    		unitPrice += (unit-100)*15;
		}
		else if( unit > 200){
			unitPrice = 100 * 11 ;
			unitPrice += 100 * 15 ;
			unitPrice += (unit-200)*20;
		}
		GST = 0.1 * unitPrice;
		fixTax = 700 ;
		TotalBill = unitPrice + fixTax + GST ;
	}
	else{
		if(unit <=100) unitPrice = unit * 15;
    	else if(unit >100 && unit <= 200){
    		unitPrice = 100 * 15 ;
    		unitPrice += (unit-100)*22;
		}
		else if( unit > 200){
			unitPrice = 100 * 15 ;
			unitPrice += 100 * 22 ;
			unitPrice += (unit-200)*30;
		}
		GST = 0.15 * unitPrice;
		fixTax = 1100 ;
		TotalBill = unitPrice + fixTax + GST ;
	}
	printf("Electricity Cost: %d\n",unitPrice);
	printf("GST: %d\n",GST);
	printf("NET Electricity BILL: %d\n",TotalBill);
    return 0;
}


