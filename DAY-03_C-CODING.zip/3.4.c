#include <stdio.h>
int EvenNum(int a) {
	
    return (a & 1) == 0;
}

int main() {
    int num;
    printf("Enter the number: ");
    scanf("%d", &num);

    if (EvenNum(num)) {
        printf("%d is an even number\n", num);
    } else {
        printf("%d is a odd number\n", num);
    }

    return 0;
}
