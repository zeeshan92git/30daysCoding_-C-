# include <stdio.h>
# include <stdlib.h>

int main()
{
	int x,y,z;
	
	printf("Enter three angles of a triangle: ");
	scanf("%d %d %d",&x,&y,&z);
	
	if(x+y+z == 180){
		printf("Yes, such triangle is possible");
	}
	else{
		printf("Sorry,Such Triangle can't exist");
	}
	
	return 0;
}