# include <stdio.h>
# include <stdlib.h>
# include <time.h>

//	scanf("%d",&x[i]);
//	printf("%d elements have digest equal to %d\n",cr[i],j);
int main()
{
	int a,b,c,large,small;
	printf("Enter three Numbers: ");
	scanf("%d %d %d",&a,&b,&c);
	if(a==b && b==c){
		printf("All Numbers are Same.");
	}
	else{
		large = a;
		small = a;
		if(b>a){
			large = b;
		}
		else if(b<a){
			small = b;
		}
		
		if(c>a){
			large = c;
		}
		else if(c<a){
			small = c;
		}
		
		printf("Smallest Number: %d\n",small);
		printf("Greatest Number: %d",large);
	}
	return 0;
}